1.Oldal készítője:
Medgyesi Szabolcs

2.Az oldal URL címe:



3.A weboldal témája:
A weboldalam a Nemzetközi Űrállomásról készült. Többek között megtalálható az állomás története, felépítése és látogathatósága az oldalon.


4.JavaScript kódok:
JavaScript kódot az "ISS túra" menüfül alatt használok. Lényege, hogy kiszámolja a megadott adatok alapján egy esetleges űrutazás költségeit, majd ha az illető jóváhagyja az árat felhozza a jelentkezési űrlapot.

5.Egyedi font típus:
Az egész weboldalon Space Mono font típust használtam a Google Fonts oldalról
(https://fonts.google.com/specimen/Space+Mono?query=space)

6.

7. Képek és tartalom forrásai:
https://hu.wikipedia.org/wiki/Nemzetk%C3%B6zi_%C5%B0r%C3%A1llom%C3%A1s
https://www.istockphoto.com/hu
https://pixabay.com/
https://www.flickr.com/photos/nasa2explore